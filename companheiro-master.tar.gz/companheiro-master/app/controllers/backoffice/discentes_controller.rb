class Backoffice::DiscentesController < ApplicationController
  layout "backoffice"

  def index
  end
end
