class Backoffice::AcompanhamentosController < ApplicationController
  layout"backoffice"

  def index
  end

  def new
  end
end
