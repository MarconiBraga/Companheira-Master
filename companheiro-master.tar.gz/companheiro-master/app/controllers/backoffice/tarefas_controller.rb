class Backoffice::TarefasController < ApplicationController
  layout "backoffice"

  def index
  end

  def new

  end
end
