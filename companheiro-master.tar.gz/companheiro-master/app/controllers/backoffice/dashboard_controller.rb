class Backoffice::DashboardController < ApplicationController
  layout "backoffice"

  def index
  end
end
